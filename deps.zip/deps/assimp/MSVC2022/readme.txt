Assimp repository: https://github.com/assimp/assimp
Assimp documentation: https://assimp-docs.readthedocs.io/en/latest/
